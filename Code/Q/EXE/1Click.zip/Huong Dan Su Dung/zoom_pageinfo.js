pageinfo = [[1239109151,1824],
	[1239113957,4168],
	[1239114941,9122],
	[1239112497,10852],
	[1239113389,6517],
	[1239114845,3287]];
pagedata = [ ["./chapter_2.htm","Hướng dẫn chi tiết","﻿Hướng dẫn chi tiết Top Previous Next Hướng dẫn chi tiết các chức năng. ",""],
["./di_t_virus_va_b_o_m_t.htm","Diệt Virus và bảo mật","﻿Diệt Virus và bảo mật Top Previous Next Đây là chức năng truyệt vời thứ 2 trong chương trình 1Click. Chức năng này gồm 3 phần nhỏ: Diệt Virus: Ch...",""],
["./introduction.htm","Giới Thiệu","﻿Giới thiệu về chương trình 1Click Top Next 1Click Phiên bản 1.0.0 1Click là công cụ cần thiết cho những người thiếu kinh nghiệm trong việc sửa ch...",""],
["./overview.htm","Khóa/Mở Các Tính Năng","﻿Khóa/Mở Các Tính Năng Top Previous Next Một số Virus khi lây nhiễm vào máy tính của bạn thường khóa đi một số chức năng quan trọng của máy tính. ...",""],
["./s_a_ch_a_va_ph_c_h_i_.htm","Sữa chữa và phục hồi.","﻿Sữa chữa và phục hồi. Top Previous Next Các tính năng trong chức năng này giúp bảo vệ máy tính một cách triệt để, phòng chống Virus cho máy tính ...",""],
["./tac_gi__chuong_trinh.htm","Tác giả chương trình","﻿Tác giả chương trình Top Previous Thông tin tác giả: Tác giả: Đinh Quang Trung (12/12/1993) Lớp 10T2 Trường THPT Đồng Phú. Yahoo: DinhQuangTrung9...",""]];
